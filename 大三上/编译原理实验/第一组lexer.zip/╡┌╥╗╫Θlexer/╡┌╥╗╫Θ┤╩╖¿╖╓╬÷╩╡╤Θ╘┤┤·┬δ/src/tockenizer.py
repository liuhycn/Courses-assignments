#!/usr/bin/env python

import sys
from collections import OrderedDict
import math

# Hex List
HEX_LIST = ['A', 'B', 'C', 'D', 'E', 'F', 
			'a', 'b', 'c', 'd', 'e', 'f']
# TFY List

TFY_LIST = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 
			'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n']


MAXINT = 2147483647


INTEGER       = 'INTEGER'
REAL          = 'REAL'
OCT_CONST     = 'OCT_CONST'
HEX_CONST     = 'HEX_CONST'
TFY_CONST     = 'TFY_CONST'
REAL_CONST    = 'REAL_CONST'
PLUS          = 'PLUS'
MINUS         = 'MINUS'
MUL           = 'MUL'
IF            = 'IF'
INTEGER_DIV   = 'INTEGER_DIV'
FLOAT_DIV     = 'FLOAT_DIV'
LPAREN        = 'LPAREN'
RPAREN        = 'RPAREN'
ID            = 'ID'
ASSIGN        = 'ASSIGN'
BEGIN         = 'BEGIN'
END           = 'END'
WHILE	      = 'WHILE'
NIL			  = 'NIL'
DO            = 'DO'
SEMI          = 'SEMI'
CASE		  = 'CASE'
FOR		      = 'FOR'
UNTIL		  = 'UNTIL'
DOT           = 'DOT'
PROGRAM       = 'PROGRAM'
VAR           = 'VAR'
COLON         = 'COLON'
COMMA         = 'COMMA'


EOF           = 'EOF'
PROCEDURE	  = 'PROCEDURE'

STRING        = 'STRING'
# <
LANGBRA       = 'LANGBRA'
# > 
NEQ			  = 'NEQ'
# <>
RANGBRA       = 'RANGBRA'
# [
LSQUBRA       = 'LSQUBRA'
# ]
RSQUBRA       = 'RSQUBRA'
# =
EQUAL         = 'EQUAL'
# @
AT_SIGN       = 'AT_SIGN'
# #
NUMBER_SIGN   = 'NUMBER_SIGN'
# $
DOLLAR_SIGN   = 'DOLLAR_SIGN'
# ^
TOPANGBRA     = 'TOPANGBRA'
SUB           = 'SUB'

class Token(object):
	def __init__(self, type, value):
		self.type = type
		self.value = value

	def __str__(self):
		return 'Token({type}, {value},)'.format(
			type = self.type,
			value = repr(self.value)
		)

	def __repr__(self):
		return self.__str__()

RESERVED_KEYWORDS = {
	'PROGRAM': Token('PROGRAM', 'PROGRAM'),
	'VAR': Token('VAR', 'VAR'),
	'DIV': Token('INTEGER_DIV', 'DIV'),
	'INTEGER': Token('INTEGER', 'INTEGER'),
	'IF':Token('IF', 'IF'),
	'REAL': Token('REAL', 'REAL'),
	'BEGIN': Token('BEGIN', 'BEGIN'),
	'END': Token('END', 'END'),
	'WHILE':Token('WHILE', 'WHILE'),
	'CASE':Token('CASE', 'CASE'),
	'FOR':Token('FOR', 'FOR'),
	'CASE':Token('UNTIL', 'UNTIL'),
	'NIL':Token('NIL', 'NIL'),
	'DO':Token('DO', 'DO'),
	'PROCEDURE': Token('PROCEDURE', 'PROCEDURE'), 
}

class Lexer(object):
	list_id = []
	list_key_word = []
	list_number = []
	list_signal = []
	list_string = []


	def __init__(self,text):
		self.text = text
		self.pos = 0
		self.current_char = self.text[self.pos]
		self.current_line = 1



	def error(self):
		raise Exception('Invalid character, at line %d' % self.current_line)

	def hex_to_oct(self,result,flag):
	
		if flag == 1 :
			print("发现非法16进制数据",result)
			return "非法16进制数据"+result
		sum = 0
		result = result[2:]
		if len(result) == 0:
			print("发现非法16进制数据0x")
			return "非法16进制数据0x"
		result = result[::-1]

		for i in range(len(result)):
			if ord(result[i])>=65 and ord(result[i])<=90:
				temp = ord(result[i])-55
				sum += temp*pow(16,i)
			elif ord(result[i])>=97 and ord(result[i])<=122:
				temp = ord(result[i])-87
				sum += temp*pow(16,i)
			elif ord(result[i])>=48 and ord(result[i])<=57:
				temp = int(result[i])
				sum += temp*pow(16,i)
			else:
				pass
		return str(sum)
		#print ("hex value in oct is ",sum)

	def tfy_to_oct(self,result,flag):
		
		if flag == 1 :
			print("发现非法24进制数据",result)
			return "非法24进制数据"+result
		sum = 0
		result = result[2:]
		if len(result) == 0:
			print("发现非法16进制数据0y")
			return "非法16进制数据0y"
		result = result[::-1]
		for i in range(len(result)):
			if ord(result[i])>=65 and ord(result[i])<=90:
				temp = ord(result[i])-55
				sum += temp*pow(24,i)
			elif ord(result[i])>=97 and ord(result[i])<=122:
				temp = ord(result[i])-87
				sum += temp*pow(24,i)
			elif ord(result[i])>=48 and ord(result[i])<=57:
				temp = int(result[i])
				sum += temp*pow(24,i)
			else:
				pass
		return str(sum)
		#print ("hex value in oct is ",sum)

	def number_error(self):
		
		print ("Error: line%d, Number Organization Error" % self.current_line)
		while self.current_char is not None and self.current_char != ";":
			self.advance()

	def print_blank_info(self):
		
		print ("WARNING: Cannot acquire Token because of lexer error!\n")

	

	def advance(self):
		
		self.pos += 1
		if self.pos > len(self.text)-1:
			self.current_char = None   		
		else:
			self.current_char = self.text[self.pos]

	def look_ahead(self, pos):
		
		next_char = None
		next_pos = pos+1
		if next_pos > len(self.text)-1:
			return None
		else:
			next_char = self.text[next_pos]
			return next_char

	def look_back(self, pos):
		
		previous_char = None
		previous_pos = pos-1
		if previous_pos < 0:
			return None
		else:
			previous_char = self.text[previous_pos]
			return previous_char

	def acquire_char(self, pos):

		if pos > len(self.text)-1:
			return None 
		else:
			return self.text[pos]
	
	def skip_comment(self):
		
		while self.current_char != '}':
			if ord(self.current_char) == ord('\n'):
				self.current_line += 1
			self.advance()
		self.advance() 

	def skip_another_comment(self):
		

		self.go_newline()

	def go_newline(self):
		
		while self.current_char != '\n' and self.current_char != '\r':
			if self.pos > len(self.text)-1:
				break
			self.advance()
		self.current_line += 1

	def skip_whitespace(self):
		
		while self.current_char is not None:
			if self.current_char.isspace():
				self.advance()
			else:
				break

	def peek(self):
		
		peek_pos = self.pos + 1
		if peek_pos > len(self.text) - 1:
			return None
		else:
			return self.text[peek_pos]

	def _id(self):
		
		result = ''

		while self.current_char is not None and (self.current_char.isalnum() or self.current_char == '_'):
			result += self.current_char
			self.advance()

		token = RESERVED_KEYWORDS.get(result.upper(), Token(ID, result))
		self.list_key_word.append(token)
		token.value += " "+str(self.current_line)
		return token



	def dec_number(self):
		
		result = ''
		while self.current_char is not None and self.current_char.isdigit():
			result += self.current_char
			self.advance()

		if self.current_char == '.':
			result += self.current_char
			self.advance()

			while self.current_char is not None and self.current_char.isdigit():
				result += self.current_char
				self.advance()

			token = Token('REAL_CONST', result+" "+str(self.current_line))

		else:
			if int(result) > MAXINT:
				print ("Error: The integer is exceeded!")
			token = Token('OCT_CONST', result+" "+str(self.current_line))
		
		
		# print "Get a dec_number", result

		return token


	def hex_number(self):
		
		flag = 0
		result = '0x'
		self.advance()
		self.advance()
		while True:
			if self.current_char is not None and self.current_char.isdigit():
				result += self.current_char
				self.advance()
			elif self.current_char is not None and self.current_char in HEX_LIST:
				result += self.current_char
				self.advance()
			elif self.current_char is not None and self.current_char not in HEX_LIST:
				if self.current_char == ';':
					break
				else:
					result += self.current_char
					flag = 1
					self.advance()
			
		return self.hex_to_oct(result,flag)


	def tfy_number(self):
		
		flag = 0
		result = '0y'
		self.advance()
		self.advance()
		while True:
			if self.current_char is not None and self.current_char.isdigit():
				result += self.current_char
				self.advance()
			elif self.current_char is not None and self.current_char in TFY_LIST:
				result += self.current_char
				self.advance()
			elif self.current_char is not None and self.current_char not in TFY_LIST:
				if self.current_char == ';':
					break
				else:
					result += self.current_char
					flag = 1
					self.advance()
			
		return self.tfy_to_oct(result,flag)


	

	def judge_type(self, start_pos):
		
		   
		result = -1
		isSkipPoint = False
		
		
		current_pos = start_pos
		while True: 
			if self.look_ahead(current_pos).isdigit() or self.look_ahead(current_pos) in HEX_LIST:
				# 0-9
				if self.look_ahead(current_pos).isdigit():
					int_number = int(self.look_ahead(current_pos))
					if int_number < 2 and result == -1: # bin
						result = 1
					elif int_number < 8 and int_number > 1 and result < 2: # oct
						result = 2
					elif int_number < 10 and int_number > 7 and result < 3: # dec
						result = 3
				else: # hex
					result = 4
			else:
				
				if self.look_ahead(current_pos) == ';':
					break
				
				elif self.look_ahead(current_pos) == '.':
					if not isSkipPoint:
						isSkipPoint = True
					else: 
						return None
				else: 
					return None
			current_pos += 1

		return result

	
	def handle_string(self, end_of_string):
		current_pos = self.pos
		result = ""
		self.advance() 

		while True:
			if self.current_char is not None and self.current_char != '\\' and self.current_char != end_of_string:
				result += self.current_char
				self.advance()
			elif self.current_char == '\\':
				if self.look_ahead(self.pos) != end_of_string or self.look_back(self.pos) != end_of_string:
					self.advance() # Skip  '\'
					result += self.current_char 
					self.advance()
				else: # a := '\';
					result += self.current_char
					self.advance()
					self.advance()
					break
			elif self.current_char == end_of_string:
				self.advance()
				break
			
			else:
				self.error()

		tocken = Token('STRING', result+" "+ str(self.current_line))
		self.list_string.append(tocken)
		return tocken


	

	def get_next_token(self):
		
		while self.current_char is not None:

			
			if ord(self.current_char) == ord('\n'):
				self.go_newline()
				if self.current_char == None:
					break

			
			if self.current_char == '/':
				
				if self.look_ahead(self.pos) == '/':
					self.skip_another_comment()
				else:
					self.advance()
					return Token(FLOAT_DIV, '/ '+str(self.current_line))

				if self.current_char == None:
					break

			
			if self.current_char.isspace():
				self.skip_whitespace()
				continue

			
			if self.current_char.isalpha() or self.current_char == '_':
				return self._id()

			
			if self.current_char.isdigit():
				if self.current_char != '0':
					return self.dec_number()
				else:
					current_pos = self.pos
					next_char = self.look_ahead(current_pos)

					if next_char == 'X' or next_char == 'x':
						v = self.hex_number()
						return Token(HEX_CONST, v+" "+str(self.current_line))
					elif next_char == 'Y' or next_char == 'y':
						v = self.tfy_number()
						return Token(TFY_CONST, v+" "+str(self.current_line))
					elif next_char == '0':
						flag = self.judge_type(current_pos+1) 
						
						if flag == 1:
							self.bin_number()
						elif flag == 2:
							self.oct_number()
						elif flag == 3:
							
							return self.dec_number()
						elif flag == 4:
							self.hex_number()
						else: 
							self.number_error()
					else:
						if next_char.isdigit():
							self.oct_number()
						elif next_char.isspace():
							self.advance()
							return Token(OCT_CONST, '0 '+str(self.current_line))
						else:
							self.number_error()
				

				#self.print_blank_info()


			if self.current_char == ':' and self.peek() == '=':
				self.advance()
				self.advance()
				return Token(ASSIGN, ':= '+str(self.current_line))

			if self.current_char == '=':
				self.advance()
				return Token(EQUAL, '= '+str(self.current_line))

			if self.current_char == ';':
				self.advance()
				return Token(SEMI, '; '+str(self.current_line))

			if self.current_char == '+':
				self.advance()
				return Token(PLUS, '+ '+str(self.current_line))

			if self.current_char == '-':
				self.advance()
				return Token(MINUS, '- '+str(self.current_line))

			if self.current_char == '*':
				self.advance()
				return Token(MUL, '* '+str(self.current_line))

			if self.current_char == '(':
				self.advance()
				return Token(LPAREN, '( '+str(self.current_line))

			if self.current_char == ')':
				self.advance()
				return Token(RPAREN, ') '+str(self.current_line))

			if self.current_char == '.':
				self.advance()
				return Token(DOT, '. '+str(self.current_line))

			if self.current_char == '{':
				self.advance()
				self.skip_comment()
				continue

			
			if self.current_char == '"':
				end_of_string = '"'
				return self.handle_string(end_of_string)

			if self.current_char == '\'':
				end_of_string = '\''
				return self.handle_string(end_of_string)

			if self.current_char == ':':
				self.advance()
				return Token(COLON, ': '+str(self.current_line))

			if self.current_char == ',':
				self.advance()
				return Token(COMMA, ', '+str(self.current_line))

			if self.current_char == '<':
				self.advance()
				if self.current_char == '>':
					self.advance()
					return Token(NEQ, '<> '+str(self.current_line))
				else:
					return Token(LANGBRA, '< '+str(self.current_line))

			if self.current_char == '>':
				self.advance()
				return Token(RANGBRA, '> '+str(self.current_line))

			if self.current_char == '[':
				self.advance()
				return Token(LSQUBRA, '[ '+str(self.current_line))

			if self.current_char == ']':
				self.advance()
				return Token(RSQUBRA, '] '+str(self.current_line))

			if self.current_char == '@':
				self.advance()
				return Token(AT_SIGN, '@ '+str(self.current_line))

			if self.current_char == '#':
				self.advance()
				return Token(NUMBER_SIGN, '# '+str(self.current_line))

			if self.current_char == '$':
				self.advance()
				return Token(DOLLAR_SIGN, '$ '+str(self.current_line))

			if self.current_char == '^':
				self.advance()
				return Token(TOPANGBRA, '^ '+str(self.current_line))

			self.error()

		return Token(EOF, None)
