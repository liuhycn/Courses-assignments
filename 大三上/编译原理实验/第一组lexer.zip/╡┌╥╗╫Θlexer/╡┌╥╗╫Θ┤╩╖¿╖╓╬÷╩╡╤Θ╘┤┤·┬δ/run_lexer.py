#!/usr/bin/env python

import sys
from collections import OrderedDict
from tkinter import *
from tkinter import ttk
from tkinter import Menu
from tkinter import filedialog


from src.tockenizer import Lexer

path = ""
name = []
type = []
line = []
root = Tk()  # 初始框的声明
uitext = Text(root, height=30)
columns = ("字符","类型","行号")
treeview = ttk.Treeview(root, show="headings", height=30, columns=columns)  # 表格

NUMBER_LIST = ['OCT_CONST', 'HEX_CONST', 'TFY_CONST']
STRING_LIST = ['STRING']
SEPARATOR_LIST = ['SEMI', 'LPAREN', 'RPAREN', 'RPAREN', 'RANGBRA','LSQUBRA', 'RSQUBRA']
OPERATOR_LIST = ['EQUAL', 'PLUS', 'MINUS', 'MUL', 'FLOAT_DIV', 'NEQ', 'ASSIGN']
KEYWORD_LIST = ['PROGRAM', 'VAR', 'DIV', 'INTEGER', 'REAL', 'BEGIN', 'END', 'WHILE', 'NIL', 'DO', 'PROCEDURE']



def openfile():
	dialog=filedialog.askopenfile()
	path = dialog.name
	text = open(path, 'r').read()
	uitext.insert(END,text)

def quit():
	root.quit()

def get_line(str):
	i = len(str)-1
	ans = ""
	while str[i] != ' ':
		ans = str[i]+ans
		i = i - 1
	return ans

def get_value(str):
	i = len(str)-1
	ans = ""
	while str[i] != ' ':
		ans = str[i]+ans
		i = i - 1
		pos = i
	return str[0:pos]


	
def lexer():


	lexer = Lexer(uitext.get(0.0,END))
	current_token = lexer.get_next_token()

	with open ("/Users/hyliu/Desktop/out.txt",'a+') as f1:
		with open ("/Users/hyliu/Desktop/mark.txt",'a+') as f2:
			while current_token is not None:
				if current_token.type == 'EOF':
					#print lexer.current_line
					break
				if str(current_token.type) == 'ID':
					f1.write("<id,"+get_value(str(current_token.value))+">")
					name.append(get_value(str(current_token.value)))
					type.append('标识符')
					line.append(get_line(str(current_token.value)))
				else:
					if str(current_token.type) in NUMBER_LIST:
						type.append('常量')
						f1.write("<number,"+get_value(str(current_token.value))+">")
						name.append(get_value(str(current_token.value)))
						line.append(get_line(str(current_token.value)))
					elif str(current_token.type) in SEPARATOR_LIST:
						type.append('分隔符')
						f1.write("<"+get_value(str(current_token.value))+">")
						name.append(get_value(str(current_token.value)))
						line.append(get_line(str(current_token.value)))
					elif str(current_token.type) in OPERATOR_LIST:
						type.append('运算符')
						f1.write("<"+get_value(str(current_token.value))+">")
						name.append(get_value(str(current_token.value)))
						line.append(get_line(str(current_token.value)))
					elif str(current_token.type) in STRING_LIST:
						type.append('字符串')
						f1.write("<"+get_value(str(current_token.value))+">")
						name.append(get_value(str(current_token.value)))
						line.append(get_line(str(current_token.value)))
					else:
						type.append('关键字')
						f1.write("<"+get_value(str(current_token.value))+">")
						name.append(get_value(str(current_token.value)))
						line.append(get_line(str(current_token.value)))

				f2.write("Token("+str(current_token.type)+", '"+get_value(str(current_token.value))+"')\n")
				current_token = lexer.get_next_token()

	for i in range(min(len(name),len(type),len(line))):# 写入数据
		treeview.insert('', i, values=(name[i], type[i], line[i]))
	f1.close()
	f2.close()


def ui():



	root.title("Lexer GUI")    # 添加标题
	root.geometry('700x600+500+200')
	root.resizable(0,0)

	# 创建菜单栏功能
	menuBar = Menu(root)
	l1 = Label(root, text="打开的帕斯卡代码:")
	l2 = Label(root, text="词法分析结果如下:")
	# 创建一个名为File的菜单项
	fileMenu = Menu(menuBar)
	aboutMenu = Menu(menuBar)
	menuBar.add_cascade(label="File", menu=fileMenu)
	menuBar.add_cascade(label="About", menu=aboutMenu)


	fileMenu.add_command(label="Open", command=openfile)
	fileMenu.add_command(label="Exit", command=quit)
	aboutMenu.add_command(label="Readme")

	root.config(menu=menuBar)
	
	
	b1=Button(root,text='词法分析',width=10, height=2, command=lexer)
	b2=Button(root,text='退出',width=10, height=2, command=quit)
	b1.place(x=400,y=530,anchor='nw')
	b2.place(x=540,y=530,anchor='nw')
	
	 
	# 表示列,不显示
	treeview.column("字符", width=110, anchor='center')
	treeview.column("类型", width=110, anchor='center')
	treeview.column("行号", width=110, anchor='center')
	 
	# 显示表头
	treeview.heading("字符", text="字符")
	treeview.heading("类型", text="类型")
	treeview.heading("行号", text="行号")
	 
	l1.grid(row=0, column=1, sticky=W, pady=5)
	l2.grid(row=0, column=0, sticky=W, pady=5)
	treeview.grid(row=1, column=0, sticky=N)
	uitext.grid(row=1, column=1, sticky=N)
	

	root.mainloop()  # 进入消息循环


if __name__ == '__main__':
	ui()

