## Lexer！

---

### 使用流程

1. 进入`ui`目录下：

```
cd ui
```

2. 运行程序：

```
python3 run_lexer.py
```

3. 在GUI的菜单栏中File->Open，选中文件打开。接下来点击`词法分析`按钮，即可进行词法分析。

4. 符号表存储在`out.txt`下，`out.txt`默认存储在桌面。

> Tips: 可以在 `run_lexer.py`文件的64、65行修改`out.txt`的存放位置。
