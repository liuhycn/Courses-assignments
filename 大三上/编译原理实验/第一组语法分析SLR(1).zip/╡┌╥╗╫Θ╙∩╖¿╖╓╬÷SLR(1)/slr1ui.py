#!/usr/bin/env python

import sys
from collections import OrderedDict
from tkinter import *
from tkinter import ttk
from tkinter import Menu
from tkinter import filedialog


path = ""
name = []
type = []
line = []

root = Tk()  # 初始框的声明，input
uitext = Text(root, height=30)
root1 = Tk()  # 初始框的声明，ouput
uitext1 = Text(root1, height=30)
root2 = Tk()  # 初始框的声明，table
uitext2 = Text(root2, height=45 , width=210)


def openfile():
	dialog=filedialog.askopenfile()
	path = dialog.name
	text = open(path, 'r').read()
	uitext.insert(END,text)

def quit():
	root.quit()
	root1.quit()
	root2.quit()

	
def analyse():
	
	path = "/Users/Vancasola/Desktop/SLR(1)/slr(1)2.0/slr(1)2.0/output.txt"
	text1 = open(path, 'r').read()
	uitext1.insert(END,text1)
	
def actiontable():

	path = "/Users/Vancasola/Desktop/SLR(1)/slr(1)2.0/slr(1)2.0/actionAndGoto.txt"
	text2 = open(path, 'r').read()
	uitext2.insert(END,text2)

def ui():



	root.title("SLR(1)_INPUT")    # 添加标题
	root.geometry('500x500+800+115')
	root.resizable(0,0)

	root1.title("SLR(1)_OUTPUT")    # 添加标题
	root1.geometry('500x500+100+150')
	root1.resizable(0,0)

	root2.title("ActionGotoTable")    # 添加标题
	root2.geometry('1530x700+0+0')
	root2.resizable(0,0)
	# 创建菜单栏功能
	menuBar = Menu(root)
	l1 = Label(root, text="判断的程序样例:")
	l2 = Label(root1, text="语法分析结果如下:")
	l3 = Label(root2, text="ActionGotoTable")
	# 创建一个名为File的菜单项
	fileMenu = Menu(menuBar)
	aboutMenu = Menu(menuBar)
	menuBar.add_cascade(label="File", menu=fileMenu)
	menuBar.add_cascade(label="About", menu=aboutMenu)


	fileMenu.add_command(label="Open", command=openfile)
	fileMenu.add_command(label="Exit", command=quit)
	aboutMenu.add_command(label="Readme")

	root.config(menu=menuBar)
	
	
	b1=Button(root,text='语法分析',width=10, height=2, command=analyse)
	b2=Button(root,text='退出',width=10, height=2, command=quit)
	b3=Button(root,text='ActionGotoTable',width=15, height=2, command=actiontable)
	b1.place(x=50,y=450,anchor='nw')
	b2.place(x=360,y=450,anchor='nw')
	b3.place(x=190,y=450,anchor='nw')

	l1.grid(row=0, column=1, sticky=W, pady=5)
	l2.grid(row=0, column=1, sticky=W, pady=5)
	l3.grid(row=0, column=1, sticky=W, pady=5)
	uitext.grid(row=1, column=1, sticky=N)
	uitext1.grid(row=1, column=1, sticky=N)
	uitext2.grid(row=1, column=1, sticky=N)
	root.mainloop()  # 进入消息循环
	root1.mainloop()
	root2.mainloop()

if __name__ == '__main__':
	ui()

