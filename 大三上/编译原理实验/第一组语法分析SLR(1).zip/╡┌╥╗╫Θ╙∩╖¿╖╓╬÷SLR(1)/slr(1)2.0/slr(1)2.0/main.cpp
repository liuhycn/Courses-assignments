#include "header.h"
int main() {
	char gramarFile[50] = "sign.txt";
	char outputFile[50] = "output.txt";
	char actionAndGotoFile[50] = "actionAndGoto.txt";
	char DFAFile[50] = "SLR.txt";
	char errorFile[50] = "error.txt";
	char inputFile[50] = "input.txt";


	init();
	getGrammar(gramarFile);
	getCanonical();

	calFirst();
	printFirst();
	calFollow();
	printFollow();

	printDFA(DFAFile);
	setActionAndGoto();
	printActionAndGoto(actionAndGotoFile);
	readInput(inputFile);
	solve(outputFile, errorFile);

	system("PAUSE");
	system("PAUSE");
	return 0;
}

